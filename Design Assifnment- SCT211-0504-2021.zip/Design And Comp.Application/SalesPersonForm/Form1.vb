﻿Public Class Form1
    Private Sub ComputeSaleBtn_Click(sender As Object, e As EventArgs) Handles ComputeSaleBtn.Click
        Dim Sales(2, 3) As String
        Dim Total As Integer, GrandTotal As Integer
        Dim DisplaySales As String
        Dim I As Integer, J As Integer
        'Input sales values
        For I = Sales.GetLowerBound(0) To Sales.GetUpperBound(0)
            Sales(I, 0) = InputBox("Enter the salesman's name")
            For J = Sales.GetLowerBound(1) + 1 To Sales.GetUpperBound(1)
                Sales(I, J) = InputBox("Enter the sales for item:" & J)
            Next J
        Next I
        'Compute and display sales details
        For I = Sales.GetLowerBound(0) To Sales.GetUpperBound(0)
            SalesPersonListBox.Items.Add(Sales(I, 0))
            Total = 0
            DisplaySales = String.Empty
            For J = Sales.GetLowerBound(1) + 1 To Sales.GetUpperBound(1)
                DisplaySales &= Sales(I, J) & ControlChars.Tab
                Total = Total + Convert.ToInt32(Sales(I, J))
            Next J
            SalesPersonListBox.Items.Add(DisplaySales)
            SalesPersonListBox.Items.Add("Total Sales = " & Total.ToString)
            GrandTotal = GrandTotal + Total
        Next I
        SalesPersonListBox.Items.Add("The Grand Total is:" & GrandTotal.ToString)
    End Sub
End Class
