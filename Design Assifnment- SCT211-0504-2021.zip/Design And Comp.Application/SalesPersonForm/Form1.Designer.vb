﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        SalesPersonListBox = New ListBox()
        ComputeSaleBtn = New Button()
        SuspendLayout()
        ' 
        ' SalesPersonListBox
        ' 
        SalesPersonListBox.FormattingEnabled = True
        SalesPersonListBox.Location = New Point(131, 38)
        SalesPersonListBox.Name = "SalesPersonListBox"
        SalesPersonListBox.Size = New Size(498, 292)
        SalesPersonListBox.TabIndex = 0
        ' 
        ' ComputeSaleBtn
        ' 
        ComputeSaleBtn.BackColor = Color.Firebrick
        ComputeSaleBtn.Location = New Point(367, 369)
        ComputeSaleBtn.Name = "ComputeSaleBtn"
        ComputeSaleBtn.Size = New Size(150, 46)
        ComputeSaleBtn.TabIndex = 1
        ComputeSaleBtn.Text = "Compute Sale"
        ComputeSaleBtn.UseVisualStyleBackColor = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(13F, 32F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveCaption
        ClientSize = New Size(800, 450)
        Controls.Add(ComputeSaleBtn)
        Controls.Add(SalesPersonListBox)
        ForeColor = SystemColors.ActiveCaptionText
        Name = "Form1"
        Text = "Form1"
        ResumeLayout(False)
    End Sub

    Friend WithEvents SalesPersonListBox As ListBox
    Friend WithEvents ComputeSaleBtn As Button

End Class
