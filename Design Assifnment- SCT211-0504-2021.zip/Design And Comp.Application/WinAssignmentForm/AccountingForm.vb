﻿Public Class AccountingForm
    Private Sub accountingForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        SavingsListBox.Items.Add("Savings Overview")
        CalculateAndDisplayAmounts()
    End Sub
    Private Sub CalculateAndDisplayAmounts()
        Dim originalAmount As Double = 1000000
        Dim annualInterestRate As Double = 0.05
        Dim years As Integer = 10
        SavingsListBox.Items.Clear()
        For year As Integer = 1 To years
            Dim amount As Double = originalAmount * (1 + annualInterestRate) ^ year
            SavingsListBox.Items.Add("Year " & year & ": KSh " & amount.ToString("N2"))
        Next
    End Sub

    Private Sub CloseTwoButton_Click(sender As Object, e As EventArgs) Handles CloseTwoButton.Click
        Me.Close()
    End Sub
End Class