﻿Public Class DemoForms
    Private Sub DemoForms_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GenerateMultiplicationTable()
    End Sub
    Private Sub GenerateMultiplicationTable()
        MultiplificationTable.Items.Add("Multiplication Table")
        MultiplificationTable.Items.Add(" ")
        MultiplificationTable.Items.Add(GenerateHeaderRow())
        For i As Integer = 1 To 7
            MultiplificationTable.Items.Add(GenerateRow(i))
        Next
    End Sub
    Private Function GenerateHeaderRow() As String
        Dim headerRowText As String = "* "
        For i As Integer = 1 To 7
            headerRowText &= i.ToString() & " "
        Next
        Return headerRowText.Trim()
    End Function
    Private Function GenerateRow(ByVal rowNum As Integer) As String
        Dim rowText As String = rowNum.ToString() & " "
        For j As Integer = 1 To 7
            rowText &= (rowNum * j).ToString().PadLeft(3) & " "
        Next
        Return rowText.Trim()
    End Function

    Private Sub NextButton_Click(sender As Object, e As EventArgs) Handles NextButton.Click
        Dim accountingFormInstance As New AccountingForm()
        accountingFormInstance.Show()
        Me.Hide()
    End Sub
End Class
