﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AccountingForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        SavingsListBox = New ListBox()
        CloseTwoButton = New Button()
        SuspendLayout()
        ' 
        ' SavingsListBox
        ' 
        SavingsListBox.FormattingEnabled = True
        SavingsListBox.Items.AddRange(New Object() {"Savings Overview"})
        SavingsListBox.Location = New Point(99, 44)
        SavingsListBox.Name = "SavingsListBox"
        SavingsListBox.Size = New Size(446, 292)
        SavingsListBox.TabIndex = 0
        ' 
        ' CloseTwoButton
        ' 
        CloseTwoButton.BackColor = SystemColors.ActiveCaption
        CloseTwoButton.Location = New Point(524, 366)
        CloseTwoButton.Name = "CloseTwoButton"
        CloseTwoButton.Size = New Size(105, 46)
        CloseTwoButton.TabIndex = 1
        CloseTwoButton.Text = "CLOSE"
        CloseTwoButton.UseVisualStyleBackColor = False
        ' 
        ' AccountingForm
        ' 
        AutoScaleDimensions = New SizeF(13.0F, 32.0F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveBorder
        ClientSize = New Size(800, 450)
        Controls.Add(CloseTwoButton)
        Controls.Add(SavingsListBox)
        Name = "AccountingForm"
        Text = "AccountingForm"
        ResumeLayout(False)
    End Sub

    Friend WithEvents SavingsListBox As ListBox
    Friend WithEvents NextTwoButton As Button
    Friend WithEvents CloseTwoButton As Button
End Class
