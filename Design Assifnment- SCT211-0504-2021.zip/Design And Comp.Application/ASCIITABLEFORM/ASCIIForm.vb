﻿Public Class ASCIIForm
    Private Sub StartButton_Click(sender As Object, e As EventArgs) Handles StartButton.Click
        Dim inputChar As String = InputBox("Enter a character:", "Input Character")

        If inputChar <> "" Then
            Dim nextChar As Char = GetNextCharacter(inputChar)
            MessageBox.Show("The character following " & inputChar & " is " & nextChar, "Next Character")
        End If
    End Sub
    Private Function GetNextCharacter(inputChar As String) As Char
        Dim asciiValue As Integer = Asc(inputChar)
        Dim nextAsciiValue As Integer = asciiValue + 1
        Return ChrW(nextAsciiValue)
    End Function
    Private Sub CloseButton_Click(sender As Object, e As EventArgs) Handles CloseButton.Click
        Me.Close()
    End Sub
End Class
