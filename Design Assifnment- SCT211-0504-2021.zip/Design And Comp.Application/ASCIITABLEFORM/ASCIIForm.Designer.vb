﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ASCIIForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        StartButton = New Button()
        CloseButton = New Button()
        SuspendLayout()
        ' 
        ' StartButton
        ' 
        StartButton.BackColor = Color.FromArgb(CByte(0), CByte(192), CByte(192))
        StartButton.Location = New Point(251, 135)
        StartButton.Name = "StartButton"
        StartButton.Size = New Size(253, 173)
        StartButton.TabIndex = 0
        StartButton.Text = "START "
        StartButton.UseVisualStyleBackColor = False
        ' 
        ' CloseButton
        ' 
        CloseButton.BackColor = Color.Firebrick
        CloseButton.Location = New Point(587, 368)
        CloseButton.Name = "CloseButton"
        CloseButton.Size = New Size(116, 46)
        CloseButton.TabIndex = 1
        CloseButton.Text = "Close"
        CloseButton.UseVisualStyleBackColor = False
        ' 
        ' ASCIIForm
        ' 
        AutoScaleDimensions = New SizeF(13F, 32F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ActiveBorder
        ClientSize = New Size(800, 450)
        Controls.Add(CloseButton)
        Controls.Add(StartButton)
        Name = "ASCIIForm"
        Text = "AsciiForm"
        ResumeLayout(False)
    End Sub

    Friend WithEvents StartButton As Button
    Friend WithEvents CloseButton As Button

End Class
